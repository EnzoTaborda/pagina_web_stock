<!DOCTYPE html>
<html>
  <head>
    <title>pagina web 0.1</title>
    <h1>bienvenidos!</h1>
    ingrese su usuario <br>
    <a  href="">usuario</a><br><br>
    sin usuario? registrese! <br>
    <a href="">contraseña</a><br>
    
  </head>
</html>