# pagina_web_stock
trabajo final 2023
